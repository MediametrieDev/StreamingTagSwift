//
//  StreamingTagSwift_tvOS.h
//  StreamingTagSwift_tvOS
//
//  Created by Adminlocal on 23/02/2021.
//  Copyright © 2021 Adminlocal. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for StreamingTagSwift_tvOS.
FOUNDATION_EXPORT double StreamingTagSwift_tvOSVersionNumber;

//! Project version string for StreamingTagSwift_tvOS.
FOUNDATION_EXPORT const unsigned char StreamingTagSwift_tvOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StreamingTagSwift_tvOS/PublicHeader.h>


