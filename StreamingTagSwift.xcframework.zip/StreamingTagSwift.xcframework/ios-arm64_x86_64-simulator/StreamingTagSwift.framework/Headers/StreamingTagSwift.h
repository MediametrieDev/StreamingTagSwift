//
//  StreamingTagSwift.h
//  StreamingTagSwift
//
//  Created by Adminlocal on 03/04/2020.
//  Copyright © 2020 Adminlocal. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for StreamingTagSwift.
FOUNDATION_EXPORT double StreamingTagSwiftVersionNumber;

//! Project version string for StreamingTagSwift.
FOUNDATION_EXPORT const unsigned char StreamingTagSwiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StreamingTagSwift/PublicHeader.h>


